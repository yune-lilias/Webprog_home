<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang = "en">
	<head><meta charset="UTF-8">
		<title>Logout Successful</title>
		<link href="https://codd.cs.gsu.edu/~lhenry23/Web/HW/Asg03/nerdieluv.css" type="text/css" rel="stylesheet" />
	</head>
	
	<body>
		<!-- Need to modify before upload to github -->
		<img src='icons/label.png' alt = "ic"/>
		<br>
        <br>

         
		<h1>Successfully Log out. </h1>
		<p>You have log out, the cookies will be deleted.</p>
		<div id = "bannerarea"><br>
This page is for single nerds to meet and date each other! Type in<br>
your personal information and wait for the nerdly luv to begin!<br>
Thank you for using our site.<br><br>

Results and page (C) Copyright NerdLuv Inc.<br><br>

<img src='icons/back.png' alt = "ba"/> <a href="index.php">Back to front page</a>
       
		
		
</div>
		 <a href="https://validator.w3.org/">
		<img src='icons/html.png' alt = 'h5'/></a>
        <a href = "https://jigsaw.w3.org/css-validator/">
		<img src='icons/css.png' alt = 'css'/></a>
	</body>
</html>