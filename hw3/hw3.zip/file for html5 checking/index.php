<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang = "en">
	<head><meta charset="UTF-8">
		<title>Index Page</title>
		<link href="https://codd.cs.gsu.edu/~lhenry23/Web/HW/Asg03/nerdieluv.css" type="text/css" rel="stylesheet" />
	</head>

	<body>
		<img src='icons/label.png' alt = "ic"/>
		<br>
        <br>

         <div id = "bannerarea">
		<h1>Welcome! </h1>

		<pre>
<img src='icons/signup.png' alt="su"/> <a href="signup.php">Sign up for a new account</a>
<img src='icons/match.png' alt="ma"/> <a href="matches.php">Check your matches</a>

This page is for single nerds to meet and date each other! Type in
your personal information and wait for the nerdly luv to begin!
Thank you for using our site.

Results and page (C) Copyright NerdLuv Inc.

<img src='icons/back.png' alt="ba"/> <a href="index.php">Back to front page</a>
        </pre>
		 <a href="https://validator.w3.org/">
		<img src='icons/html.png' alt = 'h5'/></a>
        <a href = "https://jigsaw.w3.org/css-validator/">
		<img src='icons/css.png' alt = 'css'/></a>
	</div>
	</body>
</html>