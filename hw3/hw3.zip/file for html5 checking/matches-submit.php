<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang = 'en'>
	<head><meta charset="UTF-8">
		<title>Matches result</title>
		<link href="https://codd.cs.gsu.edu/~lhenry23/Web/HW/Asg03/nerdieluv.css" type="text/css" rel="stylesheet" />
	</head>
	
	<body>
		<img src='icons/label.png' alt='ic'/>
		<br>
        <br>
      
         <div id = "bannerarea">
       <h1>Matches for Hu Tao:</h1>
    <div class = "match">
      <p><img src='images/bill_gates.jpg' alt="images/bill_gates.jpg"/>Bill Gates</p><ul><li><strong>gender:</strong>M</li><li><strong>age:</strong>52</li><li><strong>type:</strong>INTJ</li><li><strong>OS:</strong>Windows</li></ul><p><img src='images/oldspice_guy.jpg' alt="images/oldspice_guy.jpg"/>Oldspice Guy</p><ul><li><strong>gender:</strong>M</li><li><strong>age:</strong>36</li><li><strong>type:</strong>ENTJ</li><li><strong>OS:</strong>Windows</li></ul><p><img src='images/git_hub.jpg' alt="images/git_hub.jpg"/>Git Hub</p><ul><li><strong>gender:</strong>M</li><li><strong>age:</strong>24</li><li><strong>type:</strong>ISTJ</li><li><strong>OS:</strong>Windows</li></ul>    </div>
		<pre>
This page is for single nerds to meet and date each other! Type in
your personal information and wait for the nerdly luv to begin!
Thank you for using our site.

Results and page (C) Copyright NerdLuv Inc.

<img src='icons/back.png' alt='ba'/> <a href="index.php">Back to front page</a>
<img src='icons/back.png' alt='lo'/> <a href="logout.php">Log out</a>
        </pre>	
		</div>
     <a href="https://validator.w3.org/">
    <img src='icons/html.png' alt = 'h5'/></a>
        <a href = "https://jigsaw.w3.org/css-validator/">
    <img src='icons/css.png' alt = 'css'/></a>
	</body>


  </html>