<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
	<head><meta charset="UTF-8">
		<title>Sign up success</title>
		<link href="https://codd.cs.gsu.edu/~lhenry23/Web/HW/Asg03/nerdieluv.css" type="text/css" rel="stylesheet" />
	</head>
	
	<body>
		<!-- Need to modify before upload to github -->
		<img src='icons/label.png' alt='ic'/>
		<br>
        <br>
      
         <div id = "bannerarea">
		<h1>Thank You!</h1>


<?php
		$error = false;
		$req = array('name','gender','age','type','os','min','max');
		foreach($req as $field){
		if(!$error && !isset($_POST[$field])){ $error = true;}
	    }
		if (empty($_POST['name'])) {$error = true;}
        if ($_POST['gender'] != 'M' && $_POST['gender'] != 'F') {$error = true;}
        $pattern = "/^[EI][NS][FT][JP]$/";
        if (!preg_match($pattern, $_POST['type'])) {$error = true;}
        if ($_POST['os'] != 'Linux' && $_POST['os'] != 'Mac' && $_POST['os'] != 'Windows') {$error = true;}
        if (!is_numeric($_POST['min']) || !is_numeric($_POST['max'])) {
            echo "5";
        	$error = true;}
        if ($_POST['min'] > $_POST['max']) {
            echo "6";
        	$error = true;}
        $req2 = array('age','min','max');
        foreach($req2 as $field){
		if($_POST[$field]<0 || $_POST[$field]>99 ){
           echo $field;
			$error = true;}
	    }
         if($error)
        {
        setcookie('prev', "invalid", time() + (86400 * 30), "/");
        header("Location: error.php");
        exit();
        }
        

        $dashname = preg_replace("/[\s]/", "_", $_POST['name']);
        $newname = strtolower ("images/".$dashname.".jpg");

        $target_file = $newname;
        move_uploaded_file( $_FILES['image']['tmp_name'], $target_file );
        $uploadOk = 1;


  //      $dashname = preg_replace("/[\s]/", "_", $tmp[0]);
   //     $newname = "images/".$dashname.".jpg";
    //    copy($oldname,$newname);

       
        $originstring = file_get_contents('singles.txt');
        $data = explode("\r\n",$originstring);
        $newuser = $_POST['name'].",".$_POST['gender'].",".$_POST['age'].",".$_POST['type'].",".$_POST["os"].",".$_POST['min'].",".$_POST['max']."\r\n";

        foreach($data as $field){
		if(str_contains($field, $_POST['name'])){ 
        setcookie('prev', "exist", time() + (86400 * 30), "/");
		header("Location: error.php");
        exit();}
	    }
        $originstring = $originstring.$newuser;
        file_put_contents('singles.txt', $originstring);
        print("Welcome to NerdieLuv,");
        print($_POST['name']); 
        print("!");
		?>


		<pre>
Now <a href = "matches.php">log in to see your matches!</a>


This page is for single nerds to meet and date each other! Type in
your personal information and wait for the nerdly luv to begin!
Thank you for using our site.

Results and page (C) Copyright NerdLuv Inc.

<img src='icons/back.png' alt='ba'/> <a href="index.php">Back to front page</a>
        </pre>
		
		

		 <a href="https://validator.w3.org/">
        <img src='icons/html.png' alt='h5'/></a>
        <a href = "https://jigsaw.w3.org/css-validator/">
        <img src='icons/css.png' alt='css'/></a>
	</div>
	</body>
</html>