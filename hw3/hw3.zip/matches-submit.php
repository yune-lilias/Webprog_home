<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang = 'en'>
	<head><meta charset="UTF-8">
		<title>Matches result</title>
		<link href="https://codd.cs.gsu.edu/~lhenry23/Web/HW/Asg03/nerdieluv.css" type="text/css" rel="stylesheet" />
	</head>
	
	<body>
		<img src='icons/label.png' alt='ic'/>
		<br>
        <br>
      
         <div id = "bannerarea">
   <?php
		    $array = getdata();
        $currentuser = $array[0];
        $data = $array[1];
        $result = findmatch($currentuser,$data);
		?>
    <h1>Matches for <?=$currentuser[0]?>:</h1>
    <div class = "match">
      <?= printmatch($currentuser,$result)?>
    </div>
		<pre>
This page is for single nerds to meet and date each other! Type in
your personal information and wait for the nerdly luv to begin!
Thank you for using our site.

Results and page (C) Copyright NerdLuv Inc.

<img src='icons/back.png' alt='ba'/> <a href="index.php">Back to front page</a>
<img src='icons/back.png' alt='lo'/> <a href="logout.php">Log out</a>
        </pre>	
		</div>
     <a href="https://validator.w3.org/">
    <img src='icons/html.png' alt = 'h5'/></a>
        <a href = "https://jigsaw.w3.org/css-validator/">
    <img src='icons/css.png' alt = 'css'/></a>
	</body>


  <?php
  //get current user from cookies or form submitted and all user data from txt file
  function getdata(){
    $error = false;    
        $originstring = file_get_contents('singles.txt');
        $data = explode("\r\n",$originstring);

        if(!isset($_COOKIE['user']) || (isset($_COOKIE['user']) && !empty($_GET['name']) )){
            if (empty($_GET['name'])) {
            setcookie('prev', "empty", time() + (86400 * 30), "/");  
            header("Location: error.php");
            exit();}

        $m_array = preg_grep('/^'.$_GET['name'].'/', $data);

        if(empty($m_array))
        {
          setcookie('prev', "notfound", time() + (86400 * 30), "/");  
        header("Location: error.php");
        exit();
        }
        setcookie('user', array_values($m_array)[0], time() + (86400 * 30), "/");
         $currentuser = explode(",",array_values($m_array)[0]);
        } else { 
            $m_array = $_COOKIE['user'];
                  $currentuser = explode(",",$m_array);
        }
        return array($currentuser,$data);
  }

  //find matches
  function findmatch($currentuser,$data){
    $max = $currentuser[6];
        $min = $currentuser[5];
        $type = $currentuser[3];
        $gender = $currentuser[1];
        $os = $currentuser[4];
        $age = $currentuser[2];
        $result = array();
        $idx = array();
        for($j =0;$j<count($data)-1;$j++){
        $tmp = explode(",",$data[$j]); 
        if($tmp[1]!= $gender && $tmp[4] == $os) {
        if($tmp[2] <= $max && $tmp[2]>=$min && $age<=$tmp[6] && $age >= $tmp[5]){
            $count = 0;
            $matchtype = $tmp[3];
           for($i = 0; $i < 4; $i++){
             if($matchtype[$i] == $type[$i]){$count = $count + 1;}
        }  
        if($count >=2){array_push($result, $data[$j]);
                    array_push($idx, $j);
        }
    }}}
    return $result;
  }

  //return all matches as printable string
  function printmatch($currentuser,$result){
        if(count($result) == 0){$result =array('No Result,Awaiting,Awaiting,Awaiting,Awaiting,Awaiting'); }
        $str = "";
        for($j =0;$j<count($result);$j++){
          $res = explode(",",$result[$j]);
          $dashname = preg_replace("/[\s]/", "_", $res[0]);
          $newname = strtolower ("images/".$dashname.".jpg");

         $str1 = "<p><img src='".$newname. "' alt=\"".$newname."\"/>";
         $str2 ="".$res[0]."</p>";
         $str3 = "<ul><li><strong>gender:</strong>".$res[1]."</li>";
         $str4 = "<li><strong>age:</strong>".$res[2]."</li>";
         $str5 = "<li><strong>type:</strong>".$res[3]."</li>";
         $str6 = "<li><strong>OS:</strong>".$res[4]."</li></ul>";
         $str = $str.$str1.$str2.$str3.$str4.$str5.$str6;
        }
        return $str;
  }
  ?>
</html>